// DONT PUT AND COMMIT YOUR AWS KEYS HERE !
const CONSTANTS = {
    AWS_REGION: "us-east-1",
    AWS_CURRENT_BUCKET: "vladimir-unique-bucket-yaml-file",
    AWS_CURRENT_OBJECT: "60026.pdf"
}

module.exports = CONSTANTS;
