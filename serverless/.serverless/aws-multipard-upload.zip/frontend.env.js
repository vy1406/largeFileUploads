const CONFIG = {
    API_URL_BASE: "https://7g0tifu0t3.execute-api.us-east-1.amazonaws.com/dev/"
};