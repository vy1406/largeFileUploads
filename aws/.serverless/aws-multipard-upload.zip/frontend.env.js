const CONFIG = {
    API_URL: "https://68qb5fre0e.execute-api.ap-south-1.amazonaws.com/dev/putObject",
};