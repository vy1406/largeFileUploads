// creating this file as js, so it wont be conflicts with aws env variables
const CONSTANTS = {
    AWS_ACCESS_KEY: "AKIAXEVXYPYTGUOG6YDV",
    AWS_SECRET_ACCESS_KEY: "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",
    AWS_REGION: "us-east-1",
    AWS_CURRENT_BUCKET: "vladimir-unique-bucket-yaml-file",
    AWS_CURRENT_OBJECT: "60026.pdf"
}

module.exports = CONSTANTS;
